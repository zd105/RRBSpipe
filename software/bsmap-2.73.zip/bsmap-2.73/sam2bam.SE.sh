##convering SAM to BAM, sort and index BAM
insam=$1
srtbam=${insam%.*}.srt.bam
outbam=${insam%.*}.bam
nodupbam=${insam%.*}.srt.nodup.bam
bin=/ifs1/ST_EPI/USER/luhanlin/soft/bsmap-2.73
echo "Converting SAM to BAM ..."
if [ ! -f $insam ]; then
    echo "$insam does not exist."
    exit 1
fi
$bin/samtools/samtools view -bS $insam > $outbam
if [ $? -ne 0 ]; then
    echo "SAM2BAM conversion not sucessful."
    echo "$insam remains unchanged."
    rm -vf $outbam
    exit 1
fi

#echo "Indexing BAM ..."
#$bin/samtools/samtools index $outbam
#if [ $? -ne 0 ]; then
#    echo "BAM file indexing not sucessful."
#    exit 1
#fi

echo "Sorting BAM ..."
$bin/samtools/samtools sort $outbam ${srtbam%.*}
if [ $? -ne 0 ]; then
    echo "BAM file sorting not sucessful."
    echo "$srtbam is in unsorted BAM format."
    rm -vf $srtbam
    exit 1
fi

echo "rmdup BAM ..."
$bin/samtools/samtools rmdup -s $srtbam $nodupbam
if [ $? -ne 0 ]; then
    echo "BAM file rmdup not sucessful."
    rm -vf $nodupbam
    exit 1
fi

echo "Indexing srt.nodup.BAM ..."
$bin/samtools/samtools index $nodupbam
if [ $? -ne 0 ]; then
    echo "BAM file indexing not sucessful."
    exit 1
fi
#rm $insam
echo "SAM file to Bam with sort and nodup is done!"
exit 0
