##convering SAM to BAM, sort and index BAM
insam=$1
outbam=${insam%.*}.bam
srtbam=${insam%.*}.srt.bam
bin=`dirname $0`
echo "Converting SAM to BAM ..."
if [ ! -f $insam ]; then
    echo "$insam does not exist."
    exit 1
fi
$bin/samtools/samtools view -bS $insam > $outbam
if [ $? -ne 0 ]; then
    echo "SAM2BAM conversion not sucessful."
    echo "$insam remains unchanged."
    rm -vf $outbam
    exit 1
fi

echo "Indexing BAM ..."
$bin/samtools/samtools index $outbam
if [ $? -ne 0 ]; then
    echo "BAM file indexing not sucessful."
    exit 1
fi

echo "Sorting BAM ..."
$bin/samtools/samtools sort $outbam ${srtbam%.*}
if [ $? -ne 0 ]; then
    echo "BAM file sorting not sucessful."
    echo "$srtbam is in unsorted BAM format."
    rm -vf $srtbam
    exit 1
fi

echo "Indexing sorted BAM ..."
$bin/samtools/samtools index $srtbam
if [ $? -ne 0 ]; then
    echo "sorted BAM file indexing not sucessful."
    exit 1
fi

#rm $insam

echo "SAM file to Bam with sort and nodup is done!"
exit 0
