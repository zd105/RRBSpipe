
/*
 *
 *	708.h
 *  
 * 
 *  @author Steve Hoffmann, steve@bioinf.uni-leipzig.de
 *  @company Bioinformatics, University of Leipzig 
 *  @date 11/03/2013 09:01:21 AM EST  
 *
 */

int bratio_(double *a, double *b, double *x, double *y, double *w, 
	double *w1, long int *ierr);

